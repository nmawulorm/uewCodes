document.getElementById("btnSignUp").addEventListener("click", function() {
  var email = document.getElementById("txtEmail").value;
  var password = document.getElementById("txtPassword").value;
  var confirmPassword = document.getElementById("txtConfirmPassword").value;

  console.log("email:", email);
  console.log("Password:", password);

  if (password == "") {
    alert("Please enter a password")
  }
  else if (password == confirmPassword) {
    window.location.href = "homepage.html";
  } else {
    alert("Passwords do not much. Please try again");
  }
});